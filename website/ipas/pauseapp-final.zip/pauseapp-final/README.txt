Pause
Sukhi Gulati, Raymond Luong, Julie Ni, Kyle Qian
Stanford University, CS194H
Final Prototype

Instructions:
Install the .ipa onto your iPhone then open the app. Though we have user account creation implemented, we would like you to use one of our existing accounts. Since we are using Meteor’s back-end, we are not sure of how much space we have and don’t want to overload on space.

login: raymond
password: password

login: stanford
password: university

login: cs194h
password: isawesome

Note:
Meteor’s free hosting ends March 25, 2016. Since our app is currently hosted on Meteor’s server, it will no longer work after then.

Limitations:
Our thumb connection screen uses a minor wizard-of-oz technique to simulate a real connection. Currently, given the small size of our user base, our thumb connection backend connects the current user with another random user in our database. Ideally, we would connect the current user with another user who is on the app at the same time but it is unlikely that two users would be using the application simultaneously given the current state of our application.

On the thumb connection screen, touching down on the thumbprint begins the pulsing and flower blossom animation. However, lifting the thumb up does not stop the animation. We had to make a technical tradeoff between functionality and visual aesthetic. If we rendered the animation as a HTML5 video, we would be able to play and pause the video but the transparent background would have been lost. If we rendered the animation as a .gif image, we are able to retain the transparent background but cannot pause the animation once it starts playing. We opted for the latter option of a gif because we felt it was less disruptive to the aesthetic of our design. In addition, our ideal behavior is for users to hold their thumb down without lifting up.